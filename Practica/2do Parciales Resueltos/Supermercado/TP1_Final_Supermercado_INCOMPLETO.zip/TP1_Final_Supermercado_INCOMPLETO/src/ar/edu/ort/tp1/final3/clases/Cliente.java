package ar.edu.ort.tp1.final3.clases;

import edu.ort.tp1.u5.tda.Pila;
import edu.ort.tp1.u5.tda.nodos.PilaNodos;

public abstract class Cliente implements ClienteDescontable {
	private static final String NOMBRE_INVALIDO = "El nombre no puede ser nulo ni vacio";

	public void agregarProducto(Producto producto) {
	}

	public boolean puedeComprar(double total) {
		return false;
	}

}
