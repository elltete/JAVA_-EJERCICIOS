package ar.edu.ort.tp1.final3.clases;

import edu.ort.tp1.u5.tda.Cola;
import edu.ort.tp1.u5.tda.ListaOrdenada;
import edu.ort.tp1.u5.tda.Pila;
import edu.ort.tp1.u5.tda.nodos.ColaNodos;
import edu.ort.tp1.u5.tda.nodos.PilaNodos;

public class Supermercado {

	private static final String TIPO_CLIENTE_NO_ENCONTRADO = "El tipo de cliente que ha ingresado no se encuentra disponible";

	public Cliente crearCliente(Clientes tipo, String nombre, int edad, double dinero) {
		return null;
	}

	public void agregarAlCarrito(Cliente cliente, Producto producto) {
	}

	public void agregarAFila(Cliente cliente) {
	}

	public void atenderCaja() {
	}

	public void realizarCompra(Cliente cliente) {
	}

	public double verPrecioCarrito(Pila<Producto> carrito) {
		return 0;
	}

	public void mostrarCompras() {
	}

}
