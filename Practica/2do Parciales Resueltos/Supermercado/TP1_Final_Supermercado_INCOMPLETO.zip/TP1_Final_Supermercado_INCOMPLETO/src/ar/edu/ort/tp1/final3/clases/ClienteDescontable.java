package ar.edu.ort.tp1.final3.clases;

public interface ClienteDescontable {
	double realizarDescuento(double precio);

	boolean tieneDescuento(double precio);
}
