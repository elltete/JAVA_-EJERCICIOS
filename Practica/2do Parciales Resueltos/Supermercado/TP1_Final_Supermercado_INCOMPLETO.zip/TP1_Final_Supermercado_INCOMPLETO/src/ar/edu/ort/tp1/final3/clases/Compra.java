package ar.edu.ort.tp1.final3.clases;

public class Compra {

	private static int cantidadCompras;
	private int id;

	public Compra(double precio, Cliente cliente, boolean descuento) {
		this.id = cantidadCompras;
		cantidadCompras = cantidadCompras + 1;
	}

}
