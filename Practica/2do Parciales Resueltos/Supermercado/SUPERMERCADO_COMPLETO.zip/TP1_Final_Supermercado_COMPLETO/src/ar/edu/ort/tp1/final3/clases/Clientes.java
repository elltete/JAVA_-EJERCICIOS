package ar.edu.ort.tp1.final3.clases;

public enum Clientes {
	COBRE, PLATA, ORO, DIAMANTE;
}
