package ar.edu.ort.monedero;

import edu.ort.tp1.u5.tda.ListaOrdenada;

public class EntidadFinanciera {
	private final String MSG_CANT_CLIENTES = "La cantidad de clientes no puede ser menor o igual a cero";
	private String nombre;


	public EntidadFinanciera(String nombre, int cantClientes) {
	}

	public void agregarCliente(String nombre, int edad) {
	}

	private int verificarDisponibilidad() {
	}

	public void agregarTransaccion(int nroCliente, Moneda moneda, double valor) {
	}


	public void mostrarDetalleCliente(int edad) {

	}


	public void cantMonedasPorCliente(String moneda) {
	}
}
