package ar.edu.ort.monedero;

public interface Detallable {
	void mostrarDetalle();
}
