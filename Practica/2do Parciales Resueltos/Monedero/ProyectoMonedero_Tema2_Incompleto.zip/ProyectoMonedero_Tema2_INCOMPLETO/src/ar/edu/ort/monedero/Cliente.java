package ar.edu.ort.monedero;

public class Cliente {

	
	
	
	public Cliente(String nombre, int edad){
	}	
	
	public void agregarTransaccion(Moneda moneda, double valor){
	}	
	

	public double cantMonedas(String moneda){
		double salida = 0;
		
		return salida;
	}
	
	
}
