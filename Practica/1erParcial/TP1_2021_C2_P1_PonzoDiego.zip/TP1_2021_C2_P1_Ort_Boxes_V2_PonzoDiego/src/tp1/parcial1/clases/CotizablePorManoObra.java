package tp1.parcial1.clases;

public interface CotizablePorManoObra {

	static final double COSTOHORA = 123.0;
	
	public abstract double calcularCostoHoras();
	
}
