package ejercicio_1;

public enum TipoDeLinea {
	CELULAR, FIJO, FAX
}
