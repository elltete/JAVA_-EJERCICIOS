package ejercicio_3y4;

public interface Imprimible {
	
	public void imprimir();

}
