package ar.edu.ort.tp1.pacial2.clases;

public enum TipoPizza {
	ESPECIAL, TRADICIONAL, RECTANGULAR;
}
